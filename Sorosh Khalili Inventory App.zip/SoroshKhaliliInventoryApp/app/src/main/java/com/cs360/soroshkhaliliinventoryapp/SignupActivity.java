package com.cs360.soroshkhaliliinventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class SignupActivity extends AppCompatActivity {

    // Class variables
    Button saveButton, cancelButton;
    EditText editTextEmail, editTextPhoneNumber, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // Initializing variables
        saveButton = findViewById(R.id.newAccountSaveButton);
        cancelButton = findViewById(R.id.newAccountCancelButton);
        editTextEmail = findViewById(R.id.editTextNewAccountEmail);
        editTextPhoneNumber = findViewById(R.id.editTextNewAccountPhoneNumber);
        editTextPassword = findViewById(R.id.editTextNewAccountPassword);

        // TextWatcher for email, phone number, and password input
        editTextEmail.addTextChangedListener(saveButtonTextWatcher);
        editTextPhoneNumber.addTextChangedListener(saveButtonTextWatcher);
        editTextPassword.addTextChangedListener(saveButtonTextWatcher);

        // OnClickListener for save button
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newEmail = editTextEmail.getText().toString().trim().toLowerCase();
                String newPhoneNumber = editTextPhoneNumber.getText().toString().trim();
                String newPassword = editTextPassword.getText().toString().trim();
                User newUser = new User();

                AppDatabase appDb = new AppDatabase(SignupActivity.this);

                try {
                    if(appDb.checkUser(newEmail)){
                        Toast.makeText(SignupActivity.this, "Account already exist! \nPlease login!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        appDb.addUser(newEmail, newPhoneNumber, newPassword);
                        editTextEmail.setText("");
                        editTextPhoneNumber.setText("");
                        editTextPassword.setText("");
                        Intent intentSaveButton = new Intent(SignupActivity.this, LoginActivity.class);
                        startActivity(intentSaveButton);
                    }
                }
                catch (Exception e) {
                    // Just a Test message
                    Toast.makeText(SignupActivity.this, "" + e, Toast.LENGTH_SHORT).show();
                }

                newUser.setEmail(newEmail);
                newUser.setPhoneNumber(newPhoneNumber);
                newUser.setPassword(newPassword);
            }
        });
        // OnClickListener for cancel button
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextEmail.setText("");
                editTextPhoneNumber.setText("");
                editTextPassword.setText("");
                Intent intentCancelButton = new Intent(SignupActivity.this, LoginActivity.class);
                startActivity(intentCancelButton);
            }
        });

    }

    // Method TextWatcher to ensure email, phone number, and password are not empty
    private TextWatcher saveButtonTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String emailInput = editTextEmail.getText().toString().trim();
            String phoneNumberInput = editTextPhoneNumber.getText().toString().trim();
            String passwordInput = editTextPassword.getText().toString().trim();

            saveButton.setEnabled(!emailInput.isEmpty() && !phoneNumberInput.isEmpty() && !passwordInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

}