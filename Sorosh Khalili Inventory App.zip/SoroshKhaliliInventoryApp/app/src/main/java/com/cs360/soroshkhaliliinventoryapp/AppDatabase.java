package com.cs360.soroshkhaliliinventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;


public class AppDatabase extends SQLiteOpenHelper {
    private final Context context;
    private static final String DATABASE_NAME = "SK_inventoryApp.db";
    private static final int DATABASE_VERSION = 1;

    // User table structure
    public static final class UserTable {
        public static final String TABLE_NAME = "users";
        public static final String COL_ID = "id";
        public static final String COL_EMAIL = "email";
        public static final String COL_PHONE_NUMBER = "phone_number";
        public static final String COL_PASSWORD = "password";
    }

    // Item table structure
    public static final class ItemTable {
        public static final String TABLE_NAME = "items";
        public static final String COL_ID = "id";
        public static final String COL_ITEM_NAME = "item_name";
        public static final String COL_QUANTITY = "quantity";
    }

    // Constructor
    public AppDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    // Creates the database upon accessing the database for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create users table
        db.execSQL("CREATE TABLE " + UserTable.TABLE_NAME + " (" +
                UserTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserTable.COL_EMAIL + " TEXT, " +
                UserTable.COL_PHONE_NUMBER + " TEXT, " +
                UserTable.COL_PASSWORD + " TEXT)");

        // Create items table
        db.execSQL("CREATE TABLE " + ItemTable.TABLE_NAME + " (" +
                ItemTable.COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ItemTable.COL_ITEM_NAME + " TEXT, " +
                ItemTable.COL_QUANTITY + " TEXT)");
    }

    // Upgrades the database whenever database version number changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + UserTable.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + ItemTable.TABLE_NAME);
        onCreate(db);
    }

    //===================================== User Related Methods ===================================

    // Method for adding a user to the database
    public void addUser(String email, String phoneNumber, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(UserTable.COL_EMAIL, email);
        contentValues.put(UserTable.COL_PHONE_NUMBER, phoneNumber);
        contentValues.put(UserTable.COL_PASSWORD, password);
        long result = db.insert(UserTable.TABLE_NAME, null, contentValues);
        if(result == -1) {
            Toast.makeText(context, "Add user FAILED", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Account successfully created", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    // Method for checking the existence of user in the database
    public Boolean checkUser(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sqlQuery = "SELECT * FROM " + UserTable.TABLE_NAME + " WHERE " + UserTable.COL_EMAIL + " = ?";

        Cursor cursor = db.rawQuery(sqlQuery, new String[]{ email });
        if(cursor.getCount() > 0) {
            db.close();
            return true;
        }
        else return false;
    }

    // Method for Authenticating the user
    public Boolean authenticateUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sqlQuery = "SELECT * FROM " + UserTable.TABLE_NAME + " WHERE " + UserTable.COL_EMAIL
                + " = ? and " + UserTable.COL_PASSWORD + " =?";

        Cursor cursor = db.rawQuery(sqlQuery, new String[]{ email, password });
        if(cursor.getCount() > 0) {
            db.close();
            return true;
        }
        else return false;

    }

    //===================================== Item Related Methods ===================================

    // Method for adding an item to the database
    public void addItem(String itemName, String itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put(ItemTable.COL_ITEM_NAME, itemName);
        contentValues.put(ItemTable.COL_QUANTITY, itemQuantity);
        long result = db.insert(ItemTable.TABLE_NAME, null, contentValues);
        if(result == -1) {
            Toast.makeText(context, "Add item FAILED", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Item successfully added", Toast.LENGTH_SHORT).show();
        }
    db.close();
    }

    // Method for checking the existence of item in the database
    public Boolean checkItem(String itemName) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sqlQuery = "SELECT * FROM " + ItemTable.TABLE_NAME + " WHERE " + ItemTable.COL_ITEM_NAME + " = ?";

        Cursor cursor = db.rawQuery(sqlQuery, new String[]{ itemName });
        if(cursor.getCount() > 0) {
            db.close();
            return true;
        }
        else return false;
    }

    // Method for reading all items from the database
    public Cursor readAllItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        String sqlQuery = "SELECT * FROM " + ItemTable.TABLE_NAME;

        Cursor cursor = null;
        if(db != null) {
            cursor = db.rawQuery(sqlQuery, null);
        }
        return cursor;
    }

    // Method for updating (editing) an item in the database
    public void editItem(String itemId, String itemName, String itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(ItemTable.COL_ITEM_NAME, itemName);
        contentValues.put(ItemTable.COL_QUANTITY, itemQuantity);

        long result = db.update(ItemTable.TABLE_NAME, contentValues,  "id = ?", new String[]{itemId});
        if(result == -1) {
            Toast.makeText(context, "Item update FAILED", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Item successfully updated.", Toast.LENGTH_SHORT).show();
        }
    db.close();
    }

    // Method for increasing item quantity by one ( Increment by one )
    public void increaseQuantity(String itemId, String itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        int newItemQuantity;

        newItemQuantity = Integer.parseInt(itemQuantity) + 1;
        contentValues.put(ItemTable.COL_QUANTITY, String.valueOf(newItemQuantity));
        db.update(ItemTable.TABLE_NAME, contentValues,  "id = ?", new String[]{itemId});
        db.close();
    }

    // Method for decreasing item quantity by one ( Decrement by one )
    public void decreaseQuantity(String itemId, String itemQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        int newItemQuantity;

        newItemQuantity = Integer.parseInt(itemQuantity) - 1;
        contentValues.put(ItemTable.COL_QUANTITY, String.valueOf(newItemQuantity));
        db.update(ItemTable.TABLE_NAME, contentValues,  "id = ?", new String[]{itemId});
        db.close();
    }

    // Method for deleting an item from the database
    public void deleteItem(String itemId) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(ItemTable.TABLE_NAME,"id = ?", new String[]{itemId});
        if(result == -1) {
            Toast.makeText(context, "Item delete FAILED", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Item successfully deleted.", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    // Method for deleting all items from the database
    public void deleteAllItems() {
        SQLiteDatabase db = this.getWritableDatabase();
        // Ensures item table is not empty
        Cursor cursor = readAllItems();
        if(cursor.getCount() > 0 ) {
            db.execSQL("DELETE FROM " + ItemTable.TABLE_NAME);
            db.close();
            Toast.makeText(context, "All items successfully deleted.", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Inventory list is already Empty!", Toast.LENGTH_SHORT).show();
        }
    }

}
