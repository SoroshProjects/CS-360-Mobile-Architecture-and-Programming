package com.cs360.soroshkhaliliinventoryapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {

    private Context context;
    Activity activity;
    private ArrayList itemId, itemName, itemQuantity;

    public RecyclerAdapter(Activity activity, Context context, ArrayList itemId, ArrayList itemName, ArrayList itemQuantity) {
        this.activity = activity;
        this.context = context;
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        // Variables for list rows
        ImageButton editButton, increaseButton, decreaseButton, deleteButton;
        TextView itemIdTextView, itemNameTextView, quantityTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initializing list row variables
            //itemIdTextView = itemView.findViewById(R.id.textViewItemId);
            itemNameTextView = itemView.findViewById(R.id.textViewItemName);
            quantityTextView = itemView.findViewById(R.id.textViewQuantity);
            editButton = itemView.findViewById(R.id.editItemButtonImage);
            increaseButton = itemView.findViewById(R.id.increaseQuantityButtonImage);
            decreaseButton = itemView.findViewById(R.id.decreaseQuantityButtonImage);
            deleteButton = itemView.findViewById(R.id.deleteItemButtonImage);
        }
    }

    public RecyclerAdapter() {
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            LayoutInflater inflater = LayoutInflater.from(context);
            View view = inflater.inflate(R.layout.row_format, parent, false);
            ViewHolder viewHolder = new ViewHolder(view);
            return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        //holder.itemIdTextView.setText(String.valueOf(itemId.get(position)));
        holder.itemNameTextView.setText(String.valueOf(itemName.get(position)));
        holder.quantityTextView.setText(String.valueOf(itemQuantity.get(position)));
        holder.editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (context, EdititemActivity.class);
                intent.putExtra("itemId", String.valueOf(itemId.get(position)));
                intent.putExtra("itemName", String.valueOf(itemName.get(position)));
                intent.putExtra("itemQuantity", String.valueOf(itemQuantity.get(position)));
                activity.startActivityForResult(intent, 1);
            }
        });
        holder.increaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppDatabase appDb = new AppDatabase(context);
                appDb.increaseQuantity(String.valueOf(itemId.get(position)), String.valueOf(itemQuantity.get(position)));
                activity.recreate();
            }
        });
        holder.decreaseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppDatabase appDb = new AppDatabase(context);
                appDb.decreaseQuantity(String.valueOf(itemId.get(position)), String.valueOf(itemQuantity.get(position)));
                activity.recreate();
            }
        });
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle("Delete Item");
                    builder.setMessage("Are you sure you want to permanently delete this item?");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            AppDatabase appDb = new AppDatabase(context);
                            appDb.deleteItem(String.valueOf(itemId.get(position)));
                            activity.recreate();
                        }
                    });
                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                        }
                    });
                    builder.create().show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemName.size();
    }

}
