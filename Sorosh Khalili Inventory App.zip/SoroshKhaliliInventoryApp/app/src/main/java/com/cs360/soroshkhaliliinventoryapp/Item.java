package com.cs360.soroshkhaliliinventoryapp;

public class Item {
    private int id;
    private String itemName;
    private String itemQuantity;

    // Constructor
    public Item() {}

    // Default constructor
    public Item(int id, String itemName, String itemQuantity) {
        this.id = id;
        this.itemName = itemName;
        this.itemQuantity = itemQuantity;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemQuantity() {
        return itemQuantity;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public void setItemQuantity(String itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

}
