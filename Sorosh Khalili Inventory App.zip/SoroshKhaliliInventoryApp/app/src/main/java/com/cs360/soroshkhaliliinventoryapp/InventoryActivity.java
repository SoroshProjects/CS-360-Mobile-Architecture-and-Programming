package com.cs360.soroshkhaliliinventoryapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;
import java.util.ArrayList;


public class InventoryActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    //private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;
    ImageButton addButton, deleteAllButton, smsButton;

    ArrayList<String> itemId, itemName, itemQuantity;
    RecyclerAdapter recyclerAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        smsButton = findViewById(R.id.smsButtonImage);
        addButton = findViewById(R.id.addItemButtonImage);
        deleteAllButton = findViewById(R.id.deleteAllItemButtonImage);
        recyclerView = findViewById(R.id.itemRecyclerView);
        recyclerView.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    Intent intentAddButton = new Intent(InventoryActivity.this, AdditemActivity.class);
                    startActivity(intentAddButton);
                }
                catch (Exception error) {
                    Toast.makeText(InventoryActivity.this, "" + error, Toast.LENGTH_LONG).show();
                }
            }
        });

        deleteAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
                builder.setTitle("Delete All Items");
                builder.setMessage("Are you sure you want to permanently delete all items?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        AppDatabase appDb = new AppDatabase(InventoryActivity.this);
                        appDb.deleteAllItems();
                        recreate();
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.create().show();
            }
        });

        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(InventoryActivity.this);
                builder.setTitle("SMS Alert");
                builder.setMessage("Allow Inventory App to send low inventory alert?");
                builder.setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.create().show();
            }
        });

        AppDatabase appDatabase = new AppDatabase(InventoryActivity.this);
        itemId = new ArrayList<>();
        itemName = new ArrayList<>();
        itemQuantity = new ArrayList<>();

        copyItemToArray();

        recyclerAdapter = new RecyclerAdapter(InventoryActivity.this, this , itemId, itemName, itemQuantity);
        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(InventoryActivity.this));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1) {
            recreate();
        }
    }

    void copyItemToArray() {
        AppDatabase appDb = new AppDatabase(InventoryActivity.this);
        Cursor cursor = appDb.readAllItems();
        if(cursor.getCount() != 0 ) {
            while (cursor.moveToNext()) {
                itemId.add(cursor.getString(0));
                itemName.add(cursor.getString(1));
                itemQuantity.add(cursor.getString(2));
            }
        }
    }

}