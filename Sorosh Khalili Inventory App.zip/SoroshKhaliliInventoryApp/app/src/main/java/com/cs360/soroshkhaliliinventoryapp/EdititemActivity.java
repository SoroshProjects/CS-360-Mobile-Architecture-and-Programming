package com.cs360.soroshkhaliliinventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EdititemActivity extends AppCompatActivity {

    // Class variables
    EditText editTextItemName, editTextItemQuantity;
    Button editItemSaveButton, editItemCancelButton;
    String itemId, itemName, itemQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edititem);

        // Initializing variables
        editTextItemName = findViewById(R.id.editTextEditItemName);
        editTextItemQuantity = findViewById(R.id.editTextEditItemQuantity);
        editItemSaveButton = findViewById(R.id.editItemSaveButton);
        editItemCancelButton = findViewById(R.id.editItemCancelButton);

        // TextWatcher for item name and item quantity input
        editTextItemName.addTextChangedListener(editItemSaveButtonTextWatcher);
        editTextItemQuantity.addTextChangedListener(editItemSaveButtonTextWatcher);

        // First: call this method and use Intent to set the data
        getAndSetIntentData();

        // OnClickListener for save button
        editItemSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Second: call this method to update data that comes from Intent
                AppDatabase appDb = new AppDatabase(EdititemActivity.this);
                itemName = editTextItemName.getText().toString().trim();
                itemQuantity = editTextItemQuantity.getText().toString().trim();
                appDb.editItem(itemId, itemName, itemQuantity);
                Intent intentSaveButton = new Intent(EdititemActivity.this, InventoryActivity.class);
                startActivity(intentSaveButton);
            }
        });
        // OnClickListener for cancel button
        editItemCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentCancelButton = new Intent(EdititemActivity.this, InventoryActivity.class);
                startActivity(intentCancelButton);
            }
        });
    }

    // Method to get data coming for InventoryActivity and set local variable
    void getAndSetIntentData() {
        if(getIntent().hasExtra("itemId") && getIntent().hasExtra("itemName") && getIntent().hasExtra("itemQuantity")) {
            // Getting data from Intent
            itemId = getIntent().getStringExtra("itemId");
            itemName = getIntent().getStringExtra("itemName");
            itemQuantity = getIntent().getStringExtra("itemQuantity");

            // Setting Intent data
            editTextItemName.setText(itemName);
            editTextItemQuantity.setText(itemQuantity);
        }
        else{
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        }
    }

    // Method TextWatcher to ensure item name and item quantity are not empty
    private final TextWatcher editItemSaveButtonTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String itemNameInput = editTextItemName.getText().toString().trim();
            String itemQuantityInput = editTextItemQuantity.getText().toString().trim();

            editItemSaveButton.setEnabled(!itemNameInput.isEmpty() && !itemQuantityInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };
}