package com.cs360.soroshkhaliliinventoryapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdditemActivity extends AppCompatActivity {

    // Class variables
    EditText editTextItemName, editTextItemQuantity;
    Button newItemSaveButton, newItemCancelButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_additem);

        // Initializing variables
        editTextItemName = findViewById(R.id.editTextNewItemName);
        editTextItemQuantity = findViewById(R.id.editTextNewItemQuantity);
        newItemSaveButton = findViewById(R.id.addNewItemSaveButton);
        newItemCancelButton = findViewById(R.id.addNewItemCancelButton);

        // TextWatcher for email and password input
        editTextItemName.addTextChangedListener(newItemSaveButtonTextWatcher);
        editTextItemQuantity.addTextChangedListener(newItemSaveButtonTextWatcher);

        // OnClickListener for save button
        newItemSaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newItemName = editTextItemName.getText().toString().trim().toLowerCase();
                String newItemQuantity = editTextItemQuantity.getText().toString().trim();
                AppDatabase appDb = new AppDatabase(AdditemActivity.this);

                try {
                    if(appDb.checkItem(newItemName)) {
                        Toast.makeText(AdditemActivity.this, "Item already exist!", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        appDb.addItem(newItemName, newItemQuantity);
                        editTextItemName.setText("");
                        editTextItemQuantity.setText("");
                        Intent intentSaveButton = new Intent(AdditemActivity.this, InventoryActivity.class);
                        startActivity(intentSaveButton);
                    }
                }
                catch (Exception e) {
                    // Display error message
                    Toast.makeText(AdditemActivity.this, "" + e, Toast.LENGTH_SHORT).show();
                }

            }
        });
        // OnClickListener for cancel button
        newItemCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editTextItemName.setText("");
                editTextItemQuantity.setText("");
                Intent intentCancelButton = new Intent(AdditemActivity.this, InventoryActivity.class);
                startActivity(intentCancelButton);
            }
        });

    }

    // Method TextWatcher to ensure email and password are not empty
    private final TextWatcher newItemSaveButtonTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String itemNameInput = editTextItemName.getText().toString().trim();
            String itemQuantityInput = editTextItemQuantity.getText().toString().trim();

            newItemSaveButton.setEnabled(!itemNameInput.isEmpty() && !itemQuantityInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };
}
